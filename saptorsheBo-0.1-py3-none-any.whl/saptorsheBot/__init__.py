from googletrans import Translator
import json
from ibm_watson import AssistantV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
translator = Translator()
from googletrans import Translator
translator = Translator()
class VoiceBot:
    def __init__(self):
        self.api = 'NOD7Tppgvhn2aoydjDtvqjaLjRwP4qXTJKMstQ7EBP6y'
        self.service_url = 'https://gateway-lon.watsonplatform.net/assistant/api'
        self.code = 0     #0 stands for Bengali which is bydefault set
        self.user_language = 'bn'
        self.maper = {
            'Bengali':'70c4a108-4454-4929-a9c9-b4cd42cfd241',
            'English':'995cb813-0bf5-4b8f-91c2-ca7daab2b773',
            'Hindi':'da924731-6cdf-4c12-9e9a-e960f7cef0f5',
            'beng_skill_date':'2019-11-02',
            'other_skill_date':'2020-03-07'
                     }
    
    def process(self,user_msg):
        detector = translator.detect(user_msg)
        self.user_language = str(detector.lang)
        if(self.user_language=='en'):
            date = self.maper['other_skill_date']
            assistant_id = self.maper['English']
            self.code = 1 # 1 stands for english
        elif(self.user_language=='hi'):
            date = self.maper['other_skill_date']
            assistant_id = self.maper['Hindi']
            self.code = 2 # 2 stands for Hindi
        else:
            date = self.maper['beng_skill_date']
            assistant_id = self.maper['Bengali']

        try:
            authenticator = IAMAuthenticator(self.api)
            assistant = AssistantV2(
            version= date,
            authenticator=authenticator
            )
            assistant.set_service_url(self.service_url)
            assistant.set_disable_ssl_verification(True)
            session_details = assistant.create_session(assistant_id)
            session_id = (session_details.get_result())
            session_id = session_id['session_id']
            text = translator.translate(user_msg, dest='en', src=self.user_language)
            text = text.text
            res = assistant.message(
            assistant_id=assistant_id,
            session_id=session_id,
            input={
            'message_type': 'text',
            'text': text}
            ).get_result()
            response = res['output']['generic'][0]['text']
            return (response,self.code)
        except Exception as e:
            print(e)
            return None
